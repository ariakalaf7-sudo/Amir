const test = require('node:test');
const assert = require('node:assert/strict');
const { MemFs } = require('../app/src/main/assets/www/js/fs.js');
const { ProjectManager, GMError, SUBDIRS, MAX_BACKUPS } = require('../app/src/main/assets/www/js/pm.js');

function setup() {
  let t = Date.UTC(2026, 10, 18, 12, 0, 0), r = 0;
  const fs = new MemFs();
  const pm = new ProjectManager(fs, { now: () => (t += 1000), rand: () => 'r' + String(r++).padStart(3, '0') });
  return { fs, pm };
}

test('create builds the documented folder layout and project.json', async () => {
  const { fs, pm } = setup();
  const m = await pm.create('  My   Game ');
  assert.equal(m.name, 'My Game');
  for (const d of SUBDIRS) assert.ok(await fs.exists(`projects/${m.id}/${d}`), d);
  assert.deepEqual(JSON.parse(await fs.read(`projects/${m.id}/project.json`)), m);
  assert.match(m.packageId, /^com\.example\.[a-z][a-z0-9]*$/);
});

test('persian names are accepted and get a valid package id', async () => {
  const { pm } = setup();
  const m = await pm.create('بازی من');
  assert.equal(m.name, 'بازی من');
  assert.match(m.packageId, /^com\.example\.game[a-z0-9]+$/);
});

test('name validation', async () => {
  const { pm } = setup();
  await assert.rejects(pm.create('   '), (e) => e instanceof GMError && e.code === 'name_empty');
  await assert.rejects(pm.create('x'.repeat(61)), (e) => e.code === 'name_long');
});

test('list is sorted by last modification, newest first', async () => {
  const { pm } = setup();
  const a = await pm.create('A'); const b = await pm.create('B');
  assert.deepEqual((await pm.list()).map((p) => p.id), [b.id, a.id]);
  await pm.rename(a.id, 'A2');
  assert.deepEqual((await pm.list()).map((p) => p.name), ['A2', 'B']);
});

test('duplicate makes an independent copy with a new id', async () => {
  const { fs, pm } = setup();
  const a = await pm.create('A');
  await fs.write(`projects/${a.id}/Scripts/player.gd`, 'extends Node');
  const c = await pm.duplicate(a.id, 'A copy');
  assert.notEqual(c.id, a.id);
  assert.equal(await fs.read(`projects/${c.id}/Scripts/player.gd`), 'extends Node');
  await fs.write(`projects/${c.id}/Scripts/player.gd`, 'changed');
  assert.equal(await fs.read(`projects/${a.id}/Scripts/player.gd`), 'extends Node');
  assert.equal((await pm.get(c.id)).name, 'A copy');
});

test('trash, restore and purge', async () => {
  const { fs, pm } = setup();
  const a = await pm.create('A');
  await pm.trash(a.id);
  assert.equal((await pm.list()).length, 0);
  assert.equal((await pm.listTrash()).length, 1);
  await pm.restore(a.id);
  assert.equal((await pm.list()).length, 1);
  await pm.trash(a.id); await pm.purge(a.id);
  assert.equal((await pm.listTrash()).length, 0);
  assert.equal(await fs.exists(`trash/${a.id}`), false);
});

test('restore refuses to overwrite an existing project', async () => {
  const { fs, pm } = setup();
  const a = await pm.create('A');
  await fs.copy(`projects/${a.id}`, `trash/${a.id}`);
  await assert.rejects(pm.restore(a.id), (e) => e.code === 'exists');
});

test('backup + restoreBackup brings back old content and keeps a safety backup', async () => {
  const { fs, pm } = setup();
  const a = await pm.create('A');
  const f = `projects/${a.id}/Scripts/main.gd`;
  await fs.write(f, 'v1');
  const b = await pm.backup(a.id);
  await fs.write(f, 'v2');
  const { safetyStamp } = await pm.restoreBackup(a.id, b.stamp);
  assert.equal(await fs.read(f), 'v1');
  assert.equal(await fs.read(`backups/${a.id}/${safetyStamp}/Scripts/main.gd`), 'v2');
});

test('restoreBackup of a missing backup fails without touching the project', async () => {
  const { fs, pm } = setup();
  const a = await pm.create('A');
  await fs.write(`projects/${a.id}/Scripts/x.gd`, 'keep');
  await assert.rejects(pm.restoreBackup(a.id, 'nope'), (e) => e.code === 'backup_missing');
  assert.equal(await fs.read(`projects/${a.id}/Scripts/x.gd`), 'keep');
});

test('only the newest backups are kept', async () => {
  const { pm } = setup();
  const a = await pm.create('A');
  for (let i = 0; i < MAX_BACKUPS + 3; i++) await pm.backup(a.id);
  assert.equal((await pm.listBackups(a.id)).length, MAX_BACKUPS);
});

test('corrupt project.json is flagged, not fatal', async () => {
  const { fs, pm } = setup();
  const a = await pm.create('A');
  await fs.write(`projects/${a.id}/project.json`, '{not json');
  const [p] = await pm.list();
  assert.equal(p.corrupt, true);
  await pm.trash(a.id); // a damaged project can still be deleted
  assert.equal((await pm.listTrash()).length, 1);
});

test('MemFs rejects path traversal', async () => {
  const fs = new MemFs();
  await assert.rejects(fs.write('../evil', 'x'));
  await assert.rejects(fs.read('projects/../../x'));
});

test('folderSummary counts files per top-level folder', async () => {
  const { fs, pm } = setup();
  const a = await pm.create('A');
  await fs.write(`projects/${a.id}/Assets/Audio/a.wav`, 'x');
  await fs.write(`projects/${a.id}/Assets/Characters/p.png`, 'x');
  const s = Object.fromEntries((await pm.folderSummary(a.id)).map((x) => [x.name, x.files]));
  assert.equal(s.Assets, 2);
  assert.equal(s.Scenes, 0);
});
