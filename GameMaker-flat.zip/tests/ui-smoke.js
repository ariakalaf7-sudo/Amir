// Optional UI smoke test: npm i playwright && npx playwright install chromium && node tests/ui-smoke.js
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const root = path.join(__dirname, '../app/src/main/assets/www');
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml' };
const srv = http.createServer((q, r) => {
  const f = path.join(root, q.url.split('?')[0] === '/' ? 'index.html' : q.url.split('?')[0]);
  fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); r.end(); } else { r.writeHead(200, { 'content-type': types[path.extname(f)] || 'application/octet-stream' }); r.end(d); } });
}).listen(0);
(async () => {
  const port = srv.address().port;
  const b = await chromium.launch();
  const pg = await b.newPage({ viewport: { width: 390, height: 780 } });
  const errs = []; pg.on('pageerror', (e) => errs.push(e.message)); pg.on('console', (m) => m.type() === 'error' && errs.push(m.text()));
  await pg.goto(`http://localhost:${port}/`);
  await pg.waitForSelector('.fab');
  const ok = (c, m) => { if (!c) throw new Error('FAIL: ' + m); console.log('ok -', m); };
  ok(await pg.locator('.empty').count() === 1, 'empty state shown');
  await pg.click('.fab'); await pg.fill('#m-input', 'بازی تست'); await pg.click('[data-mv=__input]');
  await pg.waitForSelector('.appbar h1'); ok((await pg.textContent('.appbar h1')) === 'بازی تست', 'project created and opened');
  await pg.click('[data-a=backup]'); await pg.waitForSelector('[data-a=restoreBackup]'); ok(true, 'backup created');
  await pg.screenshot({ path: path.join(require('os').tmpdir(),'gm-detail.png') });
  await pg.click('[data-a=back]'); await pg.waitForSelector('.card.tap');
  await pg.click('[data-a=menu]'); await pg.click('[data-mv=dup]'); await pg.waitForFunction(() => document.querySelectorAll('.card.tap').length === 2); ok(true, 'duplicate works');
  await pg.fill('#q', 'کپی'); ok(await pg.locator('.card.tap').count() === 1, 'search filters'); await pg.fill('#q', '');
  await pg.locator('[data-a=menu]').first().click(); await pg.click('[data-mv=delete]'); await pg.click('[data-mv=yes]');
  await pg.waitForFunction(() => document.querySelectorAll('.card.tap').length === 1); ok(true, 'moved to trash');
  await pg.click('[data-a=trash]'); await pg.waitForSelector('[data-a=untrash]'); await pg.click('[data-a=untrash]');
  await pg.waitForFunction(() => document.querySelector('.empty')); await pg.click('[data-a=back]');
  await pg.waitForFunction(() => document.querySelectorAll('.card.tap').length === 2); ok(true, 'restored from trash');
  await pg.reload(); await pg.waitForSelector('.card.tap'); ok(await pg.locator('.card.tap').count() === 2, 'data persisted after reload');
  await pg.screenshot({ path: path.join(require('os').tmpdir(),'gm-list.png') });
  await pg.click('[data-a=tab][data-v=settings]'); await pg.click('[data-a=lang][data-v=en]');
  ok((await pg.getAttribute('html', 'dir')) === 'ltr', 'English switches to LTR');
  ok(errs.length === 0, 'no console errors ' + JSON.stringify(errs));
  await b.close(); srv.close();
})().catch((e) => { console.error(e.message); process.exit(1); });
