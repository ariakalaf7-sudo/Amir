/* Game Maker — Phase 1 UI: project manager + settings. */
(function () {
  'use strict';
  const { ProjectManager, GMError, STRINGS, NativeFs, MemFs } = window.GM;
  const VERSION = '0.1.0';
  const native = typeof window.Native !== 'undefined';
  const store = native ? new NativeFs(window.Native) : MemFs.persistent('gm-web-fs');
  const pm = new ProjectManager(store);

  const lsGet = (k) => { try { return localStorage.getItem(k); } catch (e) { return null; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} };

  const S = { lang: lsGet('gm.lang') === 'en' ? 'en' : 'fa', tab: 'projects', screen: 'list', query: '', projects: [], trashed: [], cur: null, backups: [], folders: [] };

  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const t = (k, v) => { let s = (STRINGS[S.lang] && STRINGS[S.lang][k]) || STRINGS.en[k] || k; if (v) for (const x in v) s = s.split('{' + x + '}').join(v[x]); return s; };
  const icon = (n, cls) => `<span class="icon ${cls || ''}" style="-webkit-mask-image:url(img/icons/${n}.svg);mask-image:url(img/icons/${n}.svg)" aria-hidden="true"></span>`;
  const fmt = (ts) => (ts ? new Intl.DateTimeFormat(S.lang === 'fa' ? 'fa-IR' : 'en-US', { dateStyle: 'medium', timeStyle: 'short' }).format(ts) : '—');
  const stampDate = (st) => { const m = /^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/.exec(st); return m ? Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]) : 0; };

  // ---------- toast ----------
  let toastTimer = 0;
  function toast(msg, isErr) {
    const el = $('#toast'); el.className = 'show' + (isErr ? ' err' : ''); el.innerHTML = '<span>' + esc(msg) + '</span>';
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.className = ''; }, 2400);
  }
  const errMsg = (e) => (e instanceof GMError && STRINGS.en['err_' + e.code] ? t('err_' + e.code) : t('err_generic', { m: e && e.message ? e.message : String(e) }));
  async function run(fn, okKey) { try { const r = await fn(); if (okKey) toast(t(okKey)); return r === undefined ? true : r; } catch (e) { toast(errMsg(e), true); return false; } }

  // ---------- modals ----------
  let modal = null;
  function closeModal(val) { if (!modal) return; const m = modal; modal = null; $('#modal-root').innerHTML = ''; m.resolve(val); }
  function showModal(html, center) {
    return new Promise((resolve) => {
      closeModal(null); modal = { resolve };
      $('#modal-root').innerHTML = `<div class="overlay ${center ? 'center' : ''}"><div class="sheet ${center ? 'dlg' : ''}" role="dialog" aria-modal="true">${html}</div></div>`;
      const inp = $('#m-input'); if (inp) setTimeout(() => { inp.focus(); inp.select(); }, 60);
    });
  }
  $('#modal-root').addEventListener('click', (e) => {
    const el = e.target.closest('[data-mv]');
    if (el) { const v = el.dataset.mv; return closeModal(v === '__cancel' ? null : v === '__input' ? $('#m-input').value : v); }
    if (e.target.classList.contains('overlay')) closeModal(null);
  });
  $('#modal-root').addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.id === 'm-input') closeModal(e.target.value); });
  const promptDialog = (title, value, okKey) => showModal(`<h2>${esc(title)}</h2><input id="m-input" maxlength="60" value="${esc(value || '')}" placeholder="${esc(t('projectName'))}" autocomplete="off"><div class="acts"><button class="btn" data-mv="__cancel">${t('cancel')}</button><button class="btn primary" data-mv="__input">${t(okKey)}</button></div>`, true);
  const confirmDialog = async (title, body, okKey, danger) => (await showModal(`<h2>${esc(title)}</h2><p>${esc(body)}</p><div class="acts"><button class="btn" data-mv="__cancel">${t('cancel')}</button><button class="btn ${danger ? 'danger' : 'primary'}" data-mv="yes">${t(okKey)}</button></div>`, true)) === 'yes';
  const sheet = (title, opts) => showModal(`<h2>${esc(title)}</h2>` + opts.map((o) => `<button class="opt ${o.danger ? 'danger' : ''}" data-mv="${o.key}">${icon(o.icon)}<span>${esc(o.label)}</span></button>`).join(''), false);

  // ---------- views ----------
  const tabbar = () => `<nav class="tabbar">${[['projects', 'projects'], ['settings', 'settings']].map(([k, ic]) => `<button class="${S.tab === k ? 'on' : ''}" data-a="tab" data-v="${k}">${icon(ic)}<span>${t(k)}</span></button>`).join('')}</nav>`;
  const appbar = (title, left, right) => `<header class="appbar">${left || ''}${title}${right || ''}</header>`;
  const backBtn = () => `<button class="iconbtn" data-a="back" aria-label="${t('back')}">${icon('back', 'rtl-flip')}</button>`;
  const iconBtn = (a, ic, label, id) => `<button class="iconbtn" data-a="${a}" ${id ? `data-id="${esc(id)}"` : ''} aria-label="${esc(label)}">${icon(ic)}</button>`;

  function projectCards() {
    const q = S.query.trim().toLowerCase();
    const list = S.projects.filter((p) => !q || p.name.toLowerCase().includes(q));
    if (!S.projects.length) return `<div class="empty">${icon('folder-plus')}<b>${t('empty')}</b><span>${t('emptyHint')}</span></div>`;
    if (!list.length) return `<div class="empty"><b>${t('noResults')}</b></div>`;
    return list.map((p) => p.corrupt
      ? `<div class="card bad"><div class="thumb">${icon('close')}</div><div class="body"><div class="name">${esc(p.name)}</div><div class="sub">${t('corrupt')}</div></div>${iconBtn('menu', 'more', t('menu'), p.id)}</div>`
      : `<div class="card tap" data-a="open" data-id="${esc(p.id)}"><div class="thumb">${icon('projects')}</div><div class="body"><div class="name">${esc(p.name)}</div><div class="sub">${t('modified')}: ${esc(fmt(p.modifiedAt))}</div></div>${iconBtn('menu', 'more', t('menu'), p.id)}</div>`).join('');
  }

  function listView() {
    return `${appbar(`<div class="brand"><img src="img/branding/gamemaker-mark.svg" alt=""><b>${t('app')}</b></div>`, '', iconBtn('trash', 'trash', t('trash')))}
      <main><label class="search">${icon('search')}<input id="q" type="search" placeholder="${esc(t('search'))}" value="${esc(S.query)}"></label><div id="plist">${projectCards()}</div></main>
      <button class="fab" data-a="new">${icon('plus')}<span>${t('newProject')}</span></button>${tabbar()}`;
  }

  function trashView() {
    const body = S.trashed.length ? S.trashed.map((p) => `<div class="card ${p.corrupt ? 'bad' : ''}"><div class="body"><div class="name">${esc(p.name)}</div><div class="sub">${p.corrupt ? t('corrupt') : esc(fmt(p.modifiedAt))}</div></div>
        ${p.corrupt ? '' : iconBtn('untrash', 'undo', t('restore'), p.id)}${iconBtn('purge', 'trash', t('deleteForever'), p.id)}</div>`).join('')
      : `<div class="empty">${icon('trash')}<b>${t('trashEmpty')}</b></div>`;
    return `${appbar(`<h1>${t('trash')}</h1>`, backBtn())}<main>${body}</main>`;
  }

  function detailView() {
    const p = S.cur;
    const rows = [[t('package'), p.packageId], [t('version'), p.version], [t('engine'), p.engine], [t('created'), fmt(p.createdAt)], [t('modified'), fmt(p.modifiedAt)]]
      .map(([k, v]) => `<div class="row"><span class="k">${esc(k)}</span><span class="v">${esc(v)}</span></div>`).join('');
    const folders = S.folders.map((f) => `<div class="row"><span class="t">${icon('folder-plus')}</span><span class="t" style="direction:ltr;text-align:start">${esc(f.name)}</span><span class="k">${f.files} ${t('files')}</span></div>`).join('');
    const backups = S.backups.length ? S.backups.map((b) => `<div class="row"><div class="t">${esc(fmt(stampDate(b.stamp)))}<small>${esc(b.name)}</small></div>${iconBtn('restoreBackup', 'undo', t('restore'), b.stamp)}${iconBtn('delBackup', 'close', t('delete'), b.stamp)}</div>`).join('')
      : `<div class="row"><span class="k">${t('noBackups')}</span></div>`;
    return `${appbar(`<h1>${esc(p.name)}</h1>`, backBtn(), iconBtn('renameCur', 'edit', t('rename')) + iconBtn('trashCur', 'trash', t('delete')))}
      <main><div class="section">${t('info')}</div><div class="panel">${rows}</div>
      <div class="section">${t('folders')}</div><div class="panel">${folders}</div>
      <div class="section">${t('backups')}</div><button class="btn primary block" data-a="backup">${icon('backup')}<span>${t('makeBackup')}</span></button>
      <div class="panel" style="margin-top:10px">${backups}</div><p class="sub" style="color:var(--muted);font-size:13px">${t('keepNote')}</p></main>`;
  }

  function settingsView() {
    return `${appbar(`<h1>${t('settings')}</h1>`)}<main>
      <div class="section">${t('language')}</div><div class="seg"><button class="${S.lang === 'fa' ? 'on' : ''}" data-a="lang" data-v="fa">${STRINGS.fa.langFa}</button><button class="${S.lang === 'en' ? 'on' : ''}" data-a="lang" data-v="en">${STRINGS.en.langEn}</button></div>
      <div class="section">${t('about')}</div><div class="panel"><div class="row"><span class="t">${t('aboutBody', { v: VERSION })}</span></div>${native ? '' : `<div class="row"><span class="t">${t('storageWeb')}</span></div>`}</div>
      </main>${tabbar()}`;
  }

  function render() {
    document.documentElement.lang = S.lang; document.documentElement.dir = S.lang === 'fa' ? 'rtl' : 'ltr';
    $('#app').innerHTML = S.tab === 'settings' ? settingsView() : S.screen === 'detail' ? detailView() : S.screen === 'trash' ? trashView() : listView();
  }

  // ---------- data ----------
  async function loadList() { S.projects = await pm.list(); S.trashed = await pm.listTrash(); }
  async function openProject(id) {
    S.cur = await pm.get(id); S.backups = await pm.listBackups(id); S.folders = await pm.folderSummary(id); S.screen = 'detail'; render();
  }
  async function refreshDetail() { await openProject(S.cur.id); }
  async function goList() { S.screen = 'list'; S.tab = 'projects'; await loadList(); render(); }
  const byId = (id) => S.projects.find((p) => p.id === id);

  // ---------- actions ----------
  async function deleteProject(id) {
    const p = byId(id) || S.cur; if (!p) return;
    if (!(await confirmDialog(t('moveToTrash'), t('moveToTrashBody', { n: p.name }), 'delete', true))) return;
    if (await run(() => pm.trash(id), 'trashed_ok')) await goList();
  }

  const actions = {
    async tab(el) { S.tab = el.dataset.v; S.screen = 'list'; if (S.tab === 'projects') await loadList(); render(); },
    async lang(el) { S.lang = el.dataset.v; lsSet('gm.lang', S.lang); render(); },
    async back() { await goList(); },
    async trash() { await loadList(); S.screen = 'trash'; render(); },
    async open(el) { await run(() => openProject(el.dataset.id)); },
    async new() {
      const name = await promptDialog(t('newProject'), '', 'create'); if (name == null) return;
      const m = await run(() => pm.create(name), 'created_ok'); if (m && m !== true) { await loadList(); await run(() => openProject(m.id)); }
    },
    async menu(el) {
      const id = el.dataset.id, p = byId(id); if (!p) return;
      const opts = p.corrupt ? [{ key: 'delete', icon: 'trash', label: t('delete'), danger: true }]
        : [{ key: 'open', icon: 'projects', label: t('open') }, { key: 'rename', icon: 'edit', label: t('rename') }, { key: 'dup', icon: 'copy', label: t('duplicate') }, { key: 'delete', icon: 'trash', label: t('delete'), danger: true }];
      const pick = await sheet(p.name, opts);
      if (pick === 'open') await run(() => openProject(id));
      else if (pick === 'rename') { const n = await promptDialog(t('rename'), p.name, 'ok'); if (n != null && (await run(() => pm.rename(id, n), 'renamed_ok'))) { await loadList(); render(); } }
      else if (pick === 'dup') { if (await run(() => pm.duplicate(id, p.name + ' ' + t('copySuffix')), 'dup_ok')) { await loadList(); render(); } }
      else if (pick === 'delete') await deleteProject(id);
    },
    async renameCur() {
      const n = await promptDialog(t('rename'), S.cur.name, 'ok');
      if (n != null && (await run(() => pm.rename(S.cur.id, n), 'renamed_ok'))) await refreshDetail();
    },
    async trashCur() { await deleteProject(S.cur.id); },
    async backup() { if (await run(() => pm.backup(S.cur.id), 'backup_ok')) await refreshDetail(); },
    async restoreBackup(el) {
      if (!(await confirmDialog(t('restoreBackupTitle'), t('restoreBackupBody'), 'restore', false))) return;
      if (await run(() => pm.restoreBackup(S.cur.id, el.dataset.id), 'backup_restored')) await refreshDetail();
    },
    async delBackup(el) { if (await run(() => pm.deleteBackup(S.cur.id, el.dataset.id), 'backup_deleted')) await refreshDetail(); },
    async untrash(el) { if (await run(() => pm.restore(el.dataset.id), 'restored_ok')) { await loadList(); render(); } },
    async purge(el) {
      const p = S.trashed.find((x) => x.id === el.dataset.id); if (!p) return;
      if (!(await confirmDialog(t('purgeTitle'), t('purgeBody', { n: p.name }), 'deleteForever', true))) return;
      if (await run(() => pm.purge(p.id), 'purged_ok')) { await loadList(); render(); }
    },
  };

  $('#app').addEventListener('click', async (e) => {
    const el = e.target.closest('[data-a]'); if (!el || !actions[el.dataset.a]) return;
    try { await actions[el.dataset.a](el); } catch (err) { toast(errMsg(err), true); }
  });
  $('#app').addEventListener('input', (e) => {
    if (e.target.id === 'q') { S.query = e.target.value; $('#plist').innerHTML = projectCards(); }
  });

  // Android back button: return true when the page handled it.
  window.gmOnBack = function () {
    if (modal) { closeModal(null); return true; }
    if (S.tab !== 'projects') { S.tab = 'projects'; S.screen = 'list'; loadList().then(render); return true; }
    if (S.screen !== 'list') { goList(); return true; }
    return false;
  };

  loadList().then(render).catch((e) => { render(); toast(errMsg(e), true); });
})();
