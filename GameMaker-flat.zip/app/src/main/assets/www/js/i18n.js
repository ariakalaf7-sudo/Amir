(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.GM = Object.assign(root.GM || {}, factory());
})(typeof self !== 'undefined' ? self : this, function () {
  const STRINGS = {
    fa: {
      app: 'Game Maker', projects: 'پروژه‌ها', settings: 'تنظیمات', trash: 'سطل بازیافت',
      search: 'جستجوی پروژه…', newProject: 'پروژه جدید', projectName: 'نام پروژه', create: 'ساختن', cancel: 'انصراف',
      open: 'باز کردن', rename: 'تغییر نام', duplicate: 'کپی پروژه', delete: 'حذف', restore: 'بازیابی', deleteForever: 'حذف همیشگی',
      copySuffix: '(کپی)', empty: 'هنوز پروژه‌ای ندارید', emptyHint: 'با دکمه «پروژه جدید» اولین بازی خود را بسازید.',
      noResults: 'پروژه‌ای پیدا نشد', trashEmpty: 'سطل بازیافت خالی است', modified: 'آخرین تغییر', created: 'ساخته‌شده',
      corrupt: 'فایل project.json آسیب دیده است', moveToTrash: 'انتقال به سطل بازیافت؟',
      moveToTrashBody: 'پروژه «{n}» به سطل بازیافت می‌رود و می‌توانید آن را بازیابی کنید.',
      purgeTitle: 'حذف همیشگی؟', purgeBody: 'پروژه «{n}» و پشتیبان‌هایش برای همیشه پاک می‌شوند. این کار قابل بازگشت نیست.',
      restoreBackupTitle: 'بازیابی این پشتیبان؟', restoreBackupBody: 'وضعیت فعلی پروژه قبل از بازیابی به‌صورت خودکار پشتیبان‌گیری می‌شود.',
      info: 'اطلاعات پروژه', package: 'شناسه بسته', version: 'نسخه', engine: 'موتور', folders: 'پوشه‌های پروژه', files: 'فایل',
      backups: 'پشتیبان‌ها', makeBackup: 'ایجاد پشتیبان', noBackups: 'هنوز پشتیبانی ساخته نشده است', keepNote: 'حداکثر ۱۰ پشتیبان آخر نگهداری می‌شود.',
      language: 'زبان', langFa: 'فارسی', langEn: 'English', about: 'درباره',
      aboutBody: 'نسخه {v} — فاز ۱: مدیریت پروژه. پروژه‌ها در حافظه خصوصی برنامه ذخیره می‌شوند و هر تغییر بلافاصله ذخیره می‌شود.',
      storageWeb: 'حالت پیش‌نمایش مرورگر: داده‌ها در localStorage ذخیره می‌شوند.',
      created_ok: 'پروژه ساخته شد', renamed_ok: 'نام تغییر کرد', dup_ok: 'پروژه کپی شد', trashed_ok: 'به سطل بازیافت رفت',
      restored_ok: 'بازیابی شد', purged_ok: 'برای همیشه حذف شد', backup_ok: 'پشتیبان ساخته شد', backup_restored: 'پشتیبان بازیابی شد', backup_deleted: 'پشتیبان حذف شد',
      err_name_empty: 'نام پروژه نمی‌تواند خالی باشد', err_name_long: 'نام پروژه حداکثر ۶۰ نویسه می‌تواند باشد',
      err_not_found: 'پروژه پیدا نشد', err_exists: 'پروژه‌ای با همین شناسه از قبل وجود دارد',
      err_backup_missing: 'این پشتیبان پیدا نشد', err_backup_corrupt: 'این پشتیبان آسیب دیده است', err_generic: 'خطا: {m}',
      back: 'بازگشت', close: 'بستن', ok: 'تأیید', menu: 'گزینه‌ها',
    },
    en: {
      app: 'Game Maker', projects: 'Projects', settings: 'Settings', trash: 'Trash',
      search: 'Search projects…', newProject: 'New project', projectName: 'Project name', create: 'Create', cancel: 'Cancel',
      open: 'Open', rename: 'Rename', duplicate: 'Duplicate', delete: 'Delete', restore: 'Restore', deleteForever: 'Delete forever',
      copySuffix: '(copy)', empty: 'No projects yet', emptyHint: 'Tap “New project” to create your first game.',
      noResults: 'No matching projects', trashEmpty: 'Trash is empty', modified: 'Modified', created: 'Created',
      corrupt: 'project.json is damaged', moveToTrash: 'Move to trash?',
      moveToTrashBody: '“{n}” will be moved to the trash. You can restore it later.',
      purgeTitle: 'Delete forever?', purgeBody: '“{n}” and its backups will be permanently erased. This cannot be undone.',
      restoreBackupTitle: 'Restore this backup?', restoreBackupBody: 'The current state of the project is backed up automatically first.',
      info: 'Project info', package: 'Package ID', version: 'Version', engine: 'Engine', folders: 'Project folders', files: 'files',
      backups: 'Backups', makeBackup: 'Create backup', noBackups: 'No backups yet', keepNote: 'The latest 10 backups are kept.',
      language: 'Language', langFa: 'فارسی', langEn: 'English', about: 'About',
      aboutBody: 'Version {v} — Phase 1: project management. Projects live in app-private storage and every change is saved immediately.',
      storageWeb: 'Browser preview mode: data is stored in localStorage.',
      created_ok: 'Project created', renamed_ok: 'Renamed', dup_ok: 'Project duplicated', trashed_ok: 'Moved to trash',
      restored_ok: 'Restored', purged_ok: 'Deleted forever', backup_ok: 'Backup created', backup_restored: 'Backup restored', backup_deleted: 'Backup deleted',
      err_name_empty: 'Project name cannot be empty', err_name_long: 'Project name can be at most 60 characters',
      err_not_found: 'Project not found', err_exists: 'A project with this ID already exists',
      err_backup_missing: 'Backup not found', err_backup_corrupt: 'This backup is damaged', err_generic: 'Error: {m}',
      back: 'Back', close: 'Close', ok: 'OK', menu: 'Options',
    },
  };
  return { STRINGS };
});
