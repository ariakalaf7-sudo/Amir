/* Storage adapters. All methods are async so the backend can change later.
 *   NativeFs  -> Android bridge (window.Native, app-private storage)
 *   MemFs     -> in-memory (unit tests) / localStorage-backed (browser preview)
 * Adapter API: read, write, list, exists, mkdirs, remove, move, copy
 * Paths are relative, '/'-separated, and may never contain '..'. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.GM = Object.assign(root.GM || {}, factory());
})(typeof self !== 'undefined' ? self : this, function () {
  function norm(p) {
    const parts = String(p).split('/').filter(Boolean);
    if (parts.some((s) => s === '..' || s === '.')) throw new Error('bad path');
    return parts.join('/');
  }
  const parentOf = (p) => p.split('/').slice(0, -1).join('/');

  class MemFs {
    constructor(onChange) { this.files = new Map(); this.dirs = new Set(); this.onChange = onChange || null; }
    static persistent(key) {
      const fs = new MemFs(() => { try { localStorage.setItem(key, JSON.stringify(fs.toJSON())); } catch (e) {} });
      try { const raw = localStorage.getItem(key); if (raw) fs.fromJSON(JSON.parse(raw)); } catch (e) {}
      return fs;
    }
    toJSON() { return { files: [...this.files], dirs: [...this.dirs] }; }
    fromJSON(o) { this.files = new Map(o.files || []); this.dirs = new Set(o.dirs || []); }
    _changed() { if (this.onChange) this.onChange(); }
    _mk(p) { const parts = p.split('/').filter(Boolean); let cur = ''; for (const s of parts) { cur = cur ? cur + '/' + s : s; this.dirs.add(cur); } }
    async read(p) { p = norm(p); return this.files.has(p) ? this.files.get(p) : null; }
    async write(p, text) { p = norm(p); this._mk(parentOf(p)); this.files.set(p, String(text)); this._changed(); return true; }
    async exists(p) { p = norm(p); return this.files.has(p) || this.dirs.has(p); }
    async mkdirs(p) { this._mk(norm(p)); this._changed(); return true; }
    async list(p) {
      p = norm(p); const out = new Map();
      for (const d of this.dirs) if (parentOf(d) === p && d !== p) out.set(d.split('/').pop(), { name: d.split('/').pop(), isDir: true, size: 0 });
      for (const [f, v] of this.files) if (parentOf(f) === p) out.set(f.split('/').pop(), { name: f.split('/').pop(), isDir: false, size: v.length });
      return [...out.values()].sort((a, b) => (a.name < b.name ? -1 : 1));
    }
    _under(p) { const pre = p + '/'; return { files: [...this.files.keys()].filter((k) => k === p || k.startsWith(pre)), dirs: [...this.dirs].filter((k) => k === p || k.startsWith(pre)) }; }
    async remove(p) {
      p = norm(p); if (!p) throw new Error('cannot remove root');
      const u = this._under(p); u.files.forEach((k) => this.files.delete(k)); u.dirs.forEach((k) => this.dirs.delete(k));
      this._changed(); return true;
    }
    async move(a, b) {
      a = norm(a); b = norm(b);
      if (this.files.has(b) || this.dirs.has(b)) throw new Error('destination exists');
      const u = this._under(a); this._mk(parentOf(b));
      for (const k of u.files) { this.files.set(b + k.slice(a.length), this.files.get(k)); this.files.delete(k); }
      for (const k of u.dirs) { this.dirs.delete(k); this.dirs.add(b + k.slice(a.length)); }
      this._changed(); return true;
    }
    async copy(a, b) {
      a = norm(a); b = norm(b);
      if (this.files.has(b) || this.dirs.has(b)) throw new Error('destination exists');
      const u = this._under(a); this._mk(parentOf(b));
      for (const k of u.files) this.files.set(b + k.slice(a.length), this.files.get(k));
      for (const k of u.dirs) this.dirs.add(b + k.slice(a.length));
      this._changed(); return true;
    }
  }

  class NativeFs {
    constructor(native) { this.n = native; }
    _call(name, ...args) {
      const res = JSON.parse(this.n[name](...args.map((a) => norm(a))));
      if (!res.ok) throw new Error(res.error || 'native error');
      return res.value;
    }
    async read(p) { return this._call('read', p); }
    async write(p, t) { const res = JSON.parse(this.n.write(norm(p), String(t))); if (!res.ok) throw new Error(res.error); return true; }
    async list(p) { return this._call('list', p); }
    async exists(p) { return this._call('exists', p); }
    async mkdirs(p) { return this._call('mkdirs', p); }
    async remove(p) { return this._call('remove', p); }
    async move(a, b) { return this._call('move', a, b); }
    async copy(a, b) { return this._call('copy', a, b); }
  }

  return { MemFs, NativeFs };
});
