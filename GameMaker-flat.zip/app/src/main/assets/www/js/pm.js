/* Project Manager: create / open / duplicate / rename / trash / restore,
 * plus backups. Pure logic on top of a storage adapter (see fs.js), so it is
 * unit-tested in Node and runs unchanged inside the Android WebView.
 *
 * Layout (relative to app storage root):
 *   projects/<id>/project.json + Assets/ Scenes/ Logic/ Scripts/ Export/
 *   trash/<id>/            deleted projects (restorable)
 *   backups/<id>/<stamp>/  full copies of a project */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.GM = Object.assign(root.GM || {}, factory());
})(typeof self !== 'undefined' ? self : this, function () {
  const ROOT = 'projects', TRASH = 'trash', BACKUPS = 'backups';
  const MAX_BACKUPS = 10;
  const SUBDIRS = ['Assets/Characters', 'Assets/Backgrounds', 'Assets/Animations', 'Assets/Audio', 'Scenes', 'Logic', 'Scripts', 'Export'];

  class GMError extends Error { constructor(code, msg) { super(msg || code); this.code = code; } }

  class ProjectManager {
    constructor(fs, opts) {
      opts = opts || {};
      this.fs = fs;
      this.now = opts.now || (() => Date.now());
      this.rand = opts.rand || (() => Math.random().toString(36).slice(2, 8));
    }

    static cleanName(n) {
      const s = String(n == null ? '' : n).replace(/[\u0000-\u001f]/g, '').replace(/\s+/g, ' ').trim();
      if (!s) throw new GMError('name_empty');
      if (s.length > 60) throw new GMError('name_long');
      return s;
    }

    _newId() { return 'p' + this.now().toString(36) + this.rand(); }

    _defaultPackage(name, id) {
      const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '');
      return 'com.example.' + (slug && /^[a-z]/.test(slug) ? slug.slice(0, 24) : 'game' + id.slice(-5));
    }

    async _meta(dir) {
      const txt = await this.fs.read(dir + '/project.json');
      if (txt == null) return null;
      try {
        const m = JSON.parse(txt);
        return m && typeof m.id === 'string' && typeof m.name === 'string' ? m : null;
      } catch (e) { return null; }
    }

    async _writeMeta(dir, meta) { await this.fs.write(dir + '/project.json', JSON.stringify(meta, null, 2)); }

    async create(name) {
      name = ProjectManager.cleanName(name);
      const id = this._newId(), dir = ROOT + '/' + id, t = this.now();
      const meta = { schema: 1, id, name, packageId: this._defaultPackage(name, id), version: '1.0.0', engine: 'godot-4', createdAt: t, modifiedAt: t, mainScene: null };
      try {
        for (const d of SUBDIRS) await this.fs.mkdirs(dir + '/' + d);
        await this._writeMeta(dir, meta);
      } catch (e) { await this.fs.remove(dir).catch(() => {}); throw e; }
      return meta;
    }

    async _scan(base) {
      if (!(await this.fs.exists(base))) return [];
      const out = [];
      for (const e of await this.fs.list(base)) {
        if (!e.isDir) continue;
        const m = await this._meta(base + '/' + e.name);
        out.push(m ? Object.assign({ corrupt: false }, m) : { id: e.name, name: e.name, corrupt: true, modifiedAt: 0 });
      }
      return out.sort((a, b) => b.modifiedAt - a.modifiedAt);
    }
    list() { return this._scan(ROOT); }
    listTrash() { return this._scan(TRASH); }

    async get(id) {
      const m = await this._meta(ROOT + '/' + id);
      if (!m) throw new GMError('not_found');
      return m;
    }

    async touch(id) { const m = await this.get(id); m.modifiedAt = this.now(); await this._writeMeta(ROOT + '/' + id, m); return m; }

    async rename(id, name) {
      name = ProjectManager.cleanName(name);
      const m = await this.get(id); m.name = name; m.modifiedAt = this.now();
      await this._writeMeta(ROOT + '/' + id, m); return m;
    }

    async duplicate(id, newName) {
      const m = await this.get(id);
      const nid = this._newId(), t = this.now();
      const name = ProjectManager.cleanName(newName || m.name + ' (copy)');
      await this.fs.copy(ROOT + '/' + id, ROOT + '/' + nid);
      const copy = Object.assign({}, m, { id: nid, name, createdAt: t, modifiedAt: t });
      await this._writeMeta(ROOT + '/' + nid, copy);
      return copy;
    }

    async trash(id) {
      if (!(await this.fs.exists(ROOT + '/' + id))) throw new GMError('not_found');
      if (await this.fs.exists(TRASH + '/' + id)) await this.fs.remove(TRASH + '/' + id);
      await this.fs.move(ROOT + '/' + id, TRASH + '/' + id);
    }

    async restore(id) {
      if (await this.fs.exists(ROOT + '/' + id)) throw new GMError('exists');
      await this.fs.move(TRASH + '/' + id, ROOT + '/' + id);
      const m = await this._meta(ROOT + '/' + id);
      if (m) { m.modifiedAt = this.now(); await this._writeMeta(ROOT + '/' + id, m); }
    }

    async purge(id) { await this.fs.remove(TRASH + '/' + id); await this.fs.remove(BACKUPS + '/' + id); }

    // ---- backups ----
    _stamp() { return new Date(this.now()).toISOString().replace(/[-:T]/g, '').replace('.', '-').slice(0, 19); }

    async backup(id) {
      await this.get(id);
      let stamp = this._stamp(), n = 1;
      while (await this.fs.exists(BACKUPS + '/' + id + '/' + stamp)) stamp = this._stamp() + '-' + n++;
      await this.fs.copy(ROOT + '/' + id, BACKUPS + '/' + id + '/' + stamp);
      const all = await this.listBackups(id);
      for (const old of all.slice(MAX_BACKUPS)) await this.fs.remove(BACKUPS + '/' + id + '/' + old.stamp);
      return { stamp };
    }

    async listBackups(id) {
      const base = BACKUPS + '/' + id;
      if (!(await this.fs.exists(base))) return [];
      const out = [];
      for (const e of await this.fs.list(base)) {
        if (!e.isDir) continue;
        const m = await this._meta(base + '/' + e.name);
        out.push({ stamp: e.name, name: m ? m.name : '?', modifiedAt: m ? m.modifiedAt : 0 });
      }
      return out.sort((a, b) => (a.stamp < b.stamp ? 1 : -1));
    }

    /** Restores a backup. A safety backup of the current state is taken first;
     *  if anything fails the current state is put back. */
    async restoreBackup(id, stamp) {
      const src = BACKUPS + '/' + id + '/' + stamp;
      if (!(await this._meta(src))) throw new GMError('backup_missing');
      const safety = await this.backup(id);
      const dir = ROOT + '/' + id;
      try {
        await this.fs.remove(dir);
        await this.fs.copy(src, dir);
        const m = await this._meta(dir);
        if (!m) throw new GMError('backup_corrupt');
        m.modifiedAt = this.now(); await this._writeMeta(dir, m);
      } catch (e) {
        await this.fs.remove(dir).catch(() => {});
        await this.fs.copy(BACKUPS + '/' + id + '/' + safety.stamp, dir);
        throw e;
      }
      return { safetyStamp: safety.stamp };
    }

    deleteBackup(id, stamp) { return this.fs.remove(BACKUPS + '/' + id + '/' + stamp); }

    async folderSummary(id) {
      const out = [];
      for (const e of await this.fs.list(ROOT + '/' + id)) {
        if (!e.isDir) continue;
        const count = async (p) => { let n = 0; for (const c of await this.fs.list(p)) n += c.isDir ? await count(p + '/' + c.name) : 1; return n; };
        out.push({ name: e.name, files: await count(ROOT + '/' + id + '/' + e.name) });
      }
      return out;
    }
  }

  return { ProjectManager, GMError, SUBDIRS, MAX_BACKUPS };
});
