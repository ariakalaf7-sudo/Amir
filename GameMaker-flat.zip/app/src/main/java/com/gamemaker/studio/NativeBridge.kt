package com.gamemaker.studio

import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

/**
 * File API exposed to the editor UI as `window.Native`.
 * Every path is relative to the storage root and is canonicalised; anything that
 * escapes the root (e.g. "../") is rejected. All methods return a JSON string:
 * {"ok":true,"value":...} or {"ok":false,"error":"..."}.
 */
class NativeBridge(root: File) {
    private val base: File = root.apply { mkdirs() }.canonicalFile

    private fun resolve(rel: String): File {
        val f = File(base, rel).canonicalFile
        if (f != base && !f.path.startsWith(base.path + File.separator)) {
            throw SecurityException("path outside storage")
        }
        return f
    }

    private fun call(block: () -> Any?): String = try {
        JSONObject().put("ok", true).put("value", block() ?: JSONObject.NULL).toString()
    } catch (e: Exception) {
        JSONObject().put("ok", false).put("error", e.message ?: e.javaClass.simpleName).toString()
    }

    @JavascriptInterface
    fun read(path: String): String = call {
        val f = resolve(path)
        if (f.isFile) f.readText(Charsets.UTF_8) else null
    }

    @JavascriptInterface
    fun write(path: String, text: String): String = call {
        val f = resolve(path)
        f.parentFile?.mkdirs()
        // Write to a temp file first so a crash never leaves a half-written project.json.
        val tmp = File(f.path + ".tmp")
        tmp.writeText(text, Charsets.UTF_8)
        if (!tmp.renameTo(f)) {
            f.delete()
            if (!tmp.renameTo(f)) throw IOException("could not replace file")
        }
        true
    }

    @JavascriptInterface
    fun list(path: String): String = call {
        val dir = resolve(path)
        val arr = JSONArray()
        dir.listFiles()?.sortedBy { it.name }?.forEach {
            if (it.name.endsWith(".tmp")) return@forEach
            arr.put(
                JSONObject()
                    .put("name", it.name)
                    .put("isDir", it.isDirectory)
                    .put("size", if (it.isFile) it.length() else 0)
                    .put("modified", it.lastModified())
            )
        }
        arr
    }

    @JavascriptInterface
    fun exists(path: String): String = call { resolve(path).exists() }

    @JavascriptInterface
    fun mkdirs(path: String): String = call {
        val d = resolve(path)
        d.mkdirs() || d.isDirectory
    }

    @JavascriptInterface
    fun remove(path: String): String = call {
        val f = resolve(path)
        if (f == base) throw SecurityException("cannot remove root")
        if (f.exists() && !f.deleteRecursively()) throw IOException("delete failed")
        true
    }

    @JavascriptInterface
    fun move(from: String, to: String): String = call {
        val a = resolve(from)
        val b = resolve(to)
        if (b.exists()) throw IOException("destination exists")
        b.parentFile?.mkdirs()
        if (!a.renameTo(b)) throw IOException("move failed")
        true
    }

    @JavascriptInterface
    fun copy(from: String, to: String): String = call {
        val a = resolve(from)
        val b = resolve(to)
        if (b.exists()) throw IOException("destination exists")
        b.parentFile?.mkdirs()
        if (!a.copyRecursively(b, overwrite = false)) throw IOException("copy failed")
        true
    }
}
