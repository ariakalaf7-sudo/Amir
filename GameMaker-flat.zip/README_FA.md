# Game Maker — فاز ۱ (MVP): مدیریت پروژه

## وضعیت واقعی
**کار می‌کند** (با تست خودکار):
- ساخت، باز کردن، کپی، تغییر نام، حذف به سطل بازیافت، بازیابی و حذف همیشگی پروژه
- ساختار پوشه‌ای مستند: `project.json`, `Assets/{Characters,Backgrounds,Animations,Audio}`, `Scenes`, `Logic`, `Scripts`, `Export`
- پشتیبان‌گیری (۱۰ نسخه آخر) و بازیابی با پشتیبان ایمنی خودکار؛ تشخیص `project.json` خراب
- جستجو، تم تیره (#28D7B0)، فارسی/RTL و تغییر به انگلیسی، دکمه Back اندروید
- ذخیره فوری هر تغییر در حافظه خصوصی برنامه (نوشتن اتمیک، بدون نیاز به مجوز)

**هنوز ساخته نشده** (در تب‌ها نمایش داده نمی‌شوند تا دکمه بی‌عمل نداشته باشیم):
Assets (فاز ۲)، Scene Editor (۳)، Logic/Animation (۴)، اجرای Godot (۵)، Game AI (۶)، خروجی APK بازی (۷).

## گرفتن APK (بدون Android Studio)
1. پوشه را در یک مخزن GitHub بگذارید (private هم مشکلی ندارد).
2. تب **Actions ← Build APK ← Run workflow**.
3. بعد از چند دقیقه از بخش Artifacts فایل `GameMaker-debug-apk` را بگیرید، unzip کنید و `app-debug.apk` را نصب کنید.

یا با Android Studio: پوشه را باز کنید و Run بزنید (JDK 17، Gradle ≥ 8.7).

## تست
- `node --test tests/*.test.js` — ۱۳ تست واحد مدیریت پروژه و ذخیره‌سازی
- `node tests/ui-smoke.js` — تست رابط با Playwright (اختیاری)

## معماری
- `app/src/main/java/...` — پوسته Kotlin: WebView امن (فقط محتوای داخلی) + `NativeBridge` برای فایل (جلوگیری از `../`)
- `app/src/main/assets/www/` — رابط ویرایشگر؛ منطق در `js/pm.js` مستقل از اندروید است
